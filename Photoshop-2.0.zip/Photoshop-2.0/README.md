# Photoshop-2.0
CLI photo editor using Pillow.




BehradAWIR - MahdiAbediniTCH
